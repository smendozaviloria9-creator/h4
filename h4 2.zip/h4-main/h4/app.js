const API_URL = "http://localhost:3005/posts"; // Volví a poner /posts que era tu URL original, cámbiala si es /productos
const productForm = document.getElementById("productForm");
const productName = document.getElementById("productName");
const productPrice = document.getElementById("productPrice");
const productList = document.getElementById("productList");
const syncBtn = document.getElementById("syncBtn");
const formBtn = document.getElementById("formBtn");

let productos = [];
let idEnEdicion = null;

function cargarProductos() {
    const datosGuardados = localStorage.getItem("productos");
    if (datosGuardados) {
        productos = JSON.parse(datosGuardados);
        renderProductos();
    }
}

function guardarProductos() {
    localStorage.setItem("productos", JSON.stringify(productos));
}

function renderProductos() {
    productList.innerHTML = "";

    productos.forEach((producto) => {
        const li = document.createElement("li");

        const texto = document.createElement("span");
        // Una forma mucho más segura de saber si es temporal: ¿contiene la palabra 'temp-'?
        const esTemporal = producto.id && producto.id.toString().startsWith("temp-");
        texto.textContent = `${producto.nombre} - $${producto.precio} ${esTemporal ? '(Pendiente Sync)' : ''}`;
        
        const btnEditar = document.createElement("button");
        btnEditar.textContent = "Editar";
        btnEditar.style.marginLeft = "10px";
        btnEditar.addEventListener("click", () => {
            prepararEdicion(producto);
        });

        const btnEliminar = document.createElement("button");
        btnEliminar.textContent = "Eliminar";
        btnEliminar.style.marginLeft = "5px";

        btnEliminar.addEventListener("click", () => {
            eliminarProducto(producto.id);
        });

        li.appendChild(texto);
        li.appendChild(btnEditar);
        li.appendChild(btnEliminar);
        productList.appendChild(li);
    });
}

function prepararEdicion(producto) {
    productName.value = producto.nombre;
    productPrice.value = producto.precio;
    idEnEdicion = producto.id;
    if (formBtn) {
        formBtn.textContent = "Actualizar Producto";
        formBtn.style.backgroundColor = "#e0a800";
    }
}

function limpiarFormulario() {
    productName.value = "";
    productPrice.value = "";
    idEnEdicion = null;
    if (formBtn) {
        formBtn.textContent = "Agregar Producto";
        formBtn.style.backgroundColor = "";
    }
}

productForm.addEventListener("submit", async (e) => {
    e.preventDefault();

    const nombre = productName.value.trim();
    const precio = productPrice.value.trim();

    if (nombre === "" || precio === "") {
        alert("Todos los campos son obligatorios");
        return;
    }

    if (idEnEdicion !== null) {
        // --- MODO EDICIÓN ---
        const idParaActualizar = idEnEdicion;
        
        productos = productos.map(p => {
            if (String(p.id) === String(idParaActualizar)) {
                return { ...p, nombre: nombre, precio: precio };
            }
            return p;
        });
        
        guardarProductos();
        renderProductos();
        limpiarFormulario();

        await actualizarProductoAPI(idParaActualizar, { nombre, precio });

    } else {
        // --- MODO AGREGAR NUEVO ---
        // Usamos un prefijo claro para el ID temporal local
        const idTemporal = `temp-${Date.now()}`;
        const nuevoProducto = {
            id: idTemporal, 
            nombre: nombre,
            precio: precio
        };

        productos.push(nuevoProducto);
        guardarProductos();
        renderProductos();
        limpiarFormulario();

        await agregarProductoAPI(nuevoProducto, idTemporal);
    }
});

async function eliminarProducto(id) {
    if (String(id) === String(idEnEdicion)) {
        limpiarFormulario();
    }

    productos = productos.filter(p => String(p.id) !== String(id));
    guardarProductos();
    renderProductos();

    await eliminarProductoAPI(id);
}

async function obtenerProductosAPI() {
    try {
        const respuesta = await fetch(API_URL);
        if (!respuesta.ok) throw new Error("Error en GET");
        const datos = await respuesta.json();
        
        productos = datos;
        guardarProductos();
        renderProductos();
        limpiarFormulario();
        console.log("Sincronizado con el servidor");
    } catch (error) {
        console.error("Error al sincronizar:", error);
    }
}

async function agregarProductoAPI(producto, idTemporal) {
    try {
        // Enviamos al servidor únicamente las propiedades comerciales requeridas
        const productoParaEnviar = {
            nombre: producto.nombre,
            precio: producto.precio
        };

        const respuesta = await fetch(API_URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(productoParaEnviar)
        });
        
        if (!respuesta.ok) throw new Error(`HTTP error! status: ${respuesta.status}`);
        
        const productoGuardadoEnServidor = await respuesta.json();
        
        // Buscamos de forma segura comparando cadenas de texto (Strings)
        const index = productos.findIndex(p => String(p.id) === String(idTemporal));
        if (index !== -1) {
            productos[index] = productoGuardadoEnServidor;
            guardarProductos();
            renderProductos();
        }
    } catch (error) {
        console.error("Error real en el POST:", error);
    }
}

async function actualizarProductoAPI(id, productoActualizado) {
    try {
        const respuesta = await fetch(`${API_URL}/${id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(productoActualizado)
        });
        
        if (!respuesta.ok) throw new Error("Error en PUT");
        const datos = await respuesta.json();
        
        const index = productos.findIndex(p => String(p.id) === String(id));
        if (index !== -1) {
            productos[index] = datos;
            guardarProductos();
            renderProductos();
        }
    } catch (error) {
        console.error("Error en PUT:", error);
    }
}

async function eliminarProductoAPI(id) {
    try {
        // Evitamos enviar peticiones DELETE si el producto solo existe localmente
        if (String(id).startsWith("temp-")) return;

        await fetch(`${API_URL}/${id}`, { method: "DELETE" });
    } catch (error) {
        console.error("Error en DELETE:", error);
    }
}

syncBtn.addEventListener("click", obtenerProductosAPI);
cargarProductos();